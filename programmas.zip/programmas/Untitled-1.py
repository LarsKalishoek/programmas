lijst = input("Wat wilt u toevoegen aan uw boodschappen lijst?  : ")
def generateLijst(amount:str):